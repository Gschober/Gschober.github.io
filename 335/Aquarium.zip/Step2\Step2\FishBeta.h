/**
 * \file FishBeta.h
 *
 * \author George Schober
 *
 * class that represents a Beta fish
 */

#pragma once
#include <memory>

#include "Fish.h"

/**
 * Beta Fish we are creating
 */
class CFishBeta :public CFish
{
public:
	///constructor
	/// \param aquarium Aquaium of whcih to add fish to 
	CFishBeta(CAquarium * aquarium);

	/// Default constructor (disabled)
	CFishBeta() = delete;

	/// Copy constructor (disabled)
	CFishBeta(const CFishBeta &) = delete;

	///destructor
	virtual  ~CFishBeta();

	/// Handle updates for animation
	/// \param elapsed The time since the last update
	virtual void Update(double elapsed) override;

	/// Handles saving of Item data
	/// \param node XML node to add item info to 
	/// \return shared pointer to XML node
	virtual std::shared_ptr<xmlnode::CXmlNode>
		XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node) override;
	
private:
	
};

