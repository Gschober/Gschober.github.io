/**
 * \file DecorCastle.h
 *
 * \author George Schober
 *
 * class that represents castle object
 */

#pragma once
#include "Item.h"
 /**
  * Class for a castle we can add to our aquarium 
  */
class CDecorCastle :
	public CItem
{
public:
	/// Constructor
	/// \param aquarium castle is in
	CDecorCastle::CDecorCastle(CAquarium *aquarium);
	/// Destructor
	virtual ~CDecorCastle();

	/// Handles saving of castle data
	/// \param node XML node to add item info to 
	/// \return shared pointer to XML node
	virtual std::shared_ptr<xmlnode::CXmlNode>
		XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node) override;
};

