/**
 * \file FishMolly.cpp
 *
 * \author George Schober
 */
#include "stdafx.h"
#include <string>
#include "FishMolly.h"


using namespace std;
using namespace Gdiplus;

/// Fish filename 
const wstring FishMollyImageName = L"images/molly.png";


/** Constructor
 * \param aquarium The aquarium this is a member of
*/
CFishMolly::CFishMolly(CAquarium *aquarium) :
	CFish(aquarium, FishMollyImageName)
{
	SetSpeedX(80 + ((double)rand() / RAND_MAX) * (100 - 80));
	SetSpeedY(80 + ((double)rand() / RAND_MAX) * (100 - 80));
}

/**
* Destructor
*/
CFishMolly::~CFishMolly()
{
}

/**
 * Save this item to an XML node
 * \param node The node we are going to be a child of
 */
std::shared_ptr<xmlnode::CXmlNode>
CFishMolly::XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node)
{
	auto itemNode = CFish::XmlSave(node);
	itemNode->SetAttribute(L"type", L"molly");
	return itemNode;
}
