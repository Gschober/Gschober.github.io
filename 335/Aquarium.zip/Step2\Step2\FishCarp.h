/**
 * \file FishCarp.h
 *
 * \author George Schober
 *
 * Class that implements a Carp
 */
#pragma once
#include <memory>

#include "Fish.h"
 /**
  * Carp Fish we are creating
  */
class CFishCarp :public CFish
{
public:
	///constructor
	/// \param aquarium Aquaium of whcih to add fish to 
	CFishCarp(CAquarium * aquarium);

	/// Default constructor (disabled)
	CFishCarp() = delete;

	/// Copy constructor (disabled)
	CFishCarp(const CFishCarp &) = delete;

	///default action of fish in this case deleting overlapping fish
	void Swim(std::shared_ptr<CItem> item, int x, int y);

	///destructor
	virtual  ~CFishCarp();

	/// Handles saving of Carp data
	/// \param node XML node to add item info to 
	/// \return shared pointer to XML node
	virtual std::shared_ptr<xmlnode::CXmlNode>
		XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node) override;
private:
	

};