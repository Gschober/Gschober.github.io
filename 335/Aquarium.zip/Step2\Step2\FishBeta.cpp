/**
 * \file FishBeta.cpp
 *
 * \author George Schober
 */

#include "stdafx.h"
#include <string>
#include "FishBeta.h"
#include "Item.h"



using namespace std;
using namespace Gdiplus;

/// Fish filename 
const wstring FishBetaImageName = L"images/beta.png";

/** Constructor
 * \param aquarium The aquarium this is a member of
*/
CFishBeta::CFishBeta(CAquarium *aquarium) :
	CFish(aquarium, FishBetaImageName)
{
	
}

/**
* Destructor
*/
CFishBeta::~CFishBeta()
{
}

/**
 * Save this item to an XML node
 * \param node The node we are going to be a child of
 *
 * \return shared ptr to XML node
 */
std::shared_ptr<xmlnode::CXmlNode>
CFishBeta::XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node)
{
	auto itemNode = CFish::XmlSave(node);
	itemNode->SetAttribute(L"type", L"beta");
	return itemNode;
}


/**
 * Update each time increasing speed 
 * \param elapsed time pased
 */
void CFishBeta::Update(double elapsed)
{
	if (GetSpeedX()>0 && GetSpeedX() < 200)
		SetSpeedX(GetSpeedX()+.5);
	else if (GetSpeedX() < 0 && GetSpeedX() >-200)
		SetSpeedX(GetSpeedX() -.5);
	CFish::Update(elapsed);
}