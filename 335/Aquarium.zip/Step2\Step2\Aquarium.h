/**
 * \file Aquarium.h
 *
 * \author George Schober
 *
 * Class that represents an aquarium
 */

#pragma once
#include <vector>
#include <memory>
#include <algorithm>
#include "XmlNode.h"


class CItem;

/**
 * Aquarium we are creating
 */
class CAquarium
{
public:
	CAquarium();
	virtual ~CAquarium();
	/// Draw this item
	/// \param graphics Graphics device to draw on
	void OnDraw(Gdiplus::Graphics * graphics);

	/// adds fish to aquarium
	/// \param item Item to be added
	void Add(std::shared_ptr<CItem> item);

	///test if any fish in aquarium are being cliked
	/// \param x X location
	/// \param y Y location
	std::shared_ptr<CItem> HitTest(int x, int y);

	///brings clicked fish to end of list 
	/// \param item Item to move to front
	void MoveFront(std::shared_ptr<CItem>);
	
	///destroys fish overlapping fish being dragged
	/// \param item Item that is being dragged
	/// \param x X location
	/// \param y Y location
	void Destroy(std::shared_ptr<CItem> item, int x, int y);

	void Save(const std::wstring & filename);

	void Load(const std::wstring & filename);

	void Clear();

	void Update(double elapsed);

	/// Get the width of the aquarium
	/// \returns Aquarium width
	int GetWidth() const { return mBackground->GetWidth(); }

	/// Get the height of the aquarium
	/// \returns Aquarium height
	int GetHeight() const { return mBackground->GetHeight(); }

private:
	std::unique_ptr<Gdiplus::Bitmap> mBackground; ///< Background image

	/// All of the items to populate our aquarium
	std::vector<std::shared_ptr<CItem> > mItems;
	
	void XmlItem(const std::shared_ptr<xmlnode::CXmlNode>& node);
	
};

