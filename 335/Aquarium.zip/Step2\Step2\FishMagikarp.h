/**
 * \file FishMagikarp.h
 *
 * \author George Schober
 *
 * class that represents a Magikarp
 */
#pragma once
#include <memory>

#include "Fish.h"
 /**
  * Magikarp Fish we are creating
  */
class CFishMagikarp :public CFish
{
public:
	///constructor
	/// \param aquarium Aquaium of whcih to add fish to 
	CFishMagikarp(CAquarium * aquarium);

	/// Default constructor (disabled)
	CFishMagikarp() = delete;

	/// Copy constructor (disabled)
	CFishMagikarp(const CFishMagikarp &) = delete;

	/// Destructor
	virtual  ~CFishMagikarp();

	/// Handles saving of Item data
	/// \param node XML node to add item info to 
	/// \return shared pointer to XML node
	virtual std::shared_ptr<xmlnode::CXmlNode>
		XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node) override;

private:
	
};

