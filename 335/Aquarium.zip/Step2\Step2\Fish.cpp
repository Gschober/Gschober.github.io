/**
 * \file Fish.cpp
 *
 * \author George Schober
 */

#include "stdafx.h"
#include "Fish.h"
#include "Aquarium.h"

/// Maximum speed in the X direction in
/// in pixels per second
const double MaxSpeedX = 50;

/// Maximum speed in the Y direction in
/// in pixels per second
const double MaxSpeedY = 50;

/**
 * Constructor
 * \param aquarium The aquarium we are in
 * \param filename Filename for the image we use
 */
CFish::CFish(CAquarium *aquarium, const std::wstring &filename) :
	CItem(aquarium, filename)
{
	mSpeedX = ((double)rand() / RAND_MAX) * MaxSpeedX;
	mSpeedY = ((double)rand() / RAND_MAX) * MaxSpeedY;
	
}



/**
 * Deconstructor
 */
CFish::~CFish()
{
}

/**
 * Handle updates in time of our fish
 *
 * This is called before we draw and allows us to
 * move our fish. We add our speed times the amount
 * of time that has elapsed.
 * \param elapsed Time elapsed since the class call
 */
void CFish::Update(double elapsed)
{
	
	SetLocation(GetX() + mSpeedX * elapsed,
		GetY() + mSpeedY * elapsed);

	if (mSpeedX > 0 && GetX() >= (GetAquarium()->GetWidth() - 10 - (GetWidth()/2)))
	{
		mSpeedX = -mSpeedX;
		SetMirror(mSpeedX < 0);
	}
	else if (mSpeedX < 0 && GetX() <= 0 + 10 + (GetWidth() / 2))
	{
		mSpeedX = -mSpeedX;
		SetMirror(mSpeedX < 0);
	}
	if (mSpeedY > 0 && GetY() >= (GetAquarium()->GetHeight() - 10 - (GetHeight() / 2)))
	{
		mSpeedY = -mSpeedY;
		//mSpeedY = -((double)rand() / RAND_MAX) * MaxSpeedY;
	}
	else if (mSpeedY < 0 && GetY() <= 0 + 10 + (GetHeight() / 2))
	{
		mSpeedY = -mSpeedY;
		//mSpeedY = ((double)rand() / RAND_MAX) * MaxSpeedY;
	}
}

/**
 * Save Speed to XML node 
 * \param node XML node to save to 
 * \returns itemNode Node of item 
 */
std::shared_ptr<xmlnode::CXmlNode>
CFish::XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node)
{
	auto itemNode = CItem::XmlSave(node);
	itemNode->SetAttribute(L"speedX", mSpeedX);
	itemNode->SetAttribute(L"speedY", mSpeedY);
	return itemNode;
}

/**
 * Load Speed from XML file for item
 * \param node XML node to retrieve from 
 */
void CFish::XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node)
{
	CItem::XmlLoad(node);
	mSpeedX = node->GetAttributeDoubleValue(L"speedX", 0);
	SetMirror(mSpeedX < 0);
	mSpeedY = node->GetAttributeDoubleValue(L"speedY", 0);
}
