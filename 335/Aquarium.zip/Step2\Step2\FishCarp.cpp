/**
 * \file FishCarp.cpp
 *
 * \author George Schober
 */
#include "stdafx.h"
#include <string>
#include "FishCarp.h"
#include "Aquarium.h"
#include "Item.h"


using namespace std;
using namespace Gdiplus;

/// Fish filename 
const wstring FishCarpImageName = L"images/carp.png";


/** Constructor
 * \param aquarium The aquarium this is a member of
*/
CFishCarp::CFishCarp(CAquarium *aquarium) :
	CFish(aquarium, FishCarpImageName)
{
	SetSpeedY(150 + ((double)rand() / RAND_MAX) * (200 - 150));
}

/**
* Destructor
*/
CFishCarp::~CFishCarp()
{
}

/**
 * Default action of fish when being dragged
 * \param item current fish being dragged
 * \param x X location
 * \param y Y location
 */
void CFishCarp::Swim(std::shared_ptr<CItem> item, int x, int y)
{ 
	//GetAquarium()->Destroy(item, x, y);
}

/**
 * Save this item to an XML node
 * \param node The node we are going to be a child of
 */
std::shared_ptr<xmlnode::CXmlNode>
CFishCarp::XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node)
{
	auto itemNode = CFish::XmlSave(node);
	itemNode->SetAttribute(L"type", L"carp");
	return itemNode;
}