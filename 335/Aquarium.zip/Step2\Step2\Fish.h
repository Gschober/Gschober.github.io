/**
 * \file Fish.h
 *
 * \author George Schober
 *
 *  class that represents a fish type item
 */

#pragma once
#include "Item.h"
#include "XmlNode.h"
/**
 * Base class for a fish
 * This applies to all of the fish, but not the decor
 * items in the aquarium.
 */
class CFish : public CItem
{
public:
	/// Default constructor (disabled)
	CFish() = delete;

	/// Copy constructor (disabled)
	CFish(const CFish &) = delete;

	virtual ~CFish();

	/// Handle updates for animation
	/// \param elapsed The time since the last update
	virtual void Update(double elapsed);

	/// Handles saving of Item data
	/// \param node XML node to add item info to 
	/// \return shared pointer to XML node
	virtual std::shared_ptr<xmlnode::CXmlNode>
		XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node) override;

	/// Handles loading of infromation from XML format 
	/// \param node XML node to load item info from
	/// \return shared pointer to XML node
	virtual void XmlLoad(const std::shared_ptr<xmlnode::CXmlNode>& node) override;

	/// Setter for mSpeedX member variable
	/// \param num Number to change speed to 
	void SetSpeedX(double num) { mSpeedX =num; };

	/// Setter for mSpeedY member variable
	/// \param num Number to change speed to 
	void SetSpeedY(double num) { mSpeedY =num; };

	/// Getter for mSpeedX member variable
	/// \return mSpeedX member variable
	double GetSpeedX() { return mSpeedX; };
	

protected:
	/// Constructor
	CFish(CAquarium * aquarium, const std::wstring & filename);


private:
	/// Fish speed in the X direction
	double mSpeedX;

	/// Fish speed in the Y direction
	double mSpeedY;
};

