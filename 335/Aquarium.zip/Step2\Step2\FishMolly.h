/**
 * \file FishMolly.h
 *
 * \author George Schober
 *
 * Class that represents a molly fish
 */

#pragma once
#include <memory>

#include "Fish.h"
 /**
  * Molly Fish we are creating
  */
class CFishMolly :public CFish
{
public:
	///constructor
	/// \param aquarium Aquaium of whcih to add fish to 
	CFishMolly(CAquarium * aquarium);

	/// Default constructor (disabled)
	CFishMolly() = delete;

	/// Copy constructor (disabled)
	CFishMolly(const CFishMolly &) = delete;
	
	///destructor
	virtual  ~CFishMolly();

	/// Handles saving of Item data
	/// \param node XML node to add item info to 
	/// \return shared pointer to XML node
	virtual std::shared_ptr<xmlnode::CXmlNode>
		XmlSave(const std::shared_ptr<xmlnode::CXmlNode> &node) override;
private:
	
};